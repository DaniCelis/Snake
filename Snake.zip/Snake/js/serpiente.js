function Serpiente(){
	this.x = 310;
	this.y = 15;
	this.img = [$("#abajo")[0],$("#arriba")[0],$("#izquierda")[0],$("#derecha")[0],$("#salto")[0],$("#ganador")[0]];
	this.sprite = 0;
	this.vida = 100;
	this.puntos = 0;
	this.direccion = 0;
	
	this.velocidad = 0;
	while(this.velocidad == 0)
		this.velocidad=-5;
	
	this.dibujar = function(ctx){
		var img = this.img[this.sprite];
		var x = this.x;
		var y = this.y;
		ctx.drawImage(img, x, y);
		ctx.save();
		ctx.fillStyle = "#000000";
		ctx.font = "16px sans-serif";
		ctx.fillText("PUNTOS: "+ this.puntos, 530, 30);
		if(this.sprite==4){
			ctx.fillStyle = "#ff0000";
			ctx.font = "20px sans-serif";
		}
		ctx.restore();
	}
	

	this.actualizar = function(accion){
		if(accion=="arriba"){
			this.y -= 10;
			this.sprite = 1;
			this.direccion=1;
			this.y -= this.velocidad;
			this.y = (450 + this.y)%450;
		}
		if(accion=="abajo"){
			this.y += 10;
			this.sprite = 0;
			this.direccion=0;
			this.y += this.velocidad;
			this.y = (450 + this.y)%450;
		}
		if(accion=="izquierda"){
			this.x -= 10;
			this.sprite = 2;
			this.direccion=2;
			this.x -= this.velocidad;
			this.x = (600 + this.x)%600;
		}
		if(accion=="derecha"){
			this.x += 10;
			this.sprite = 3;
			this.direccion=3;
			this.x += this.velocidad;
			this.x = (600 + this.x)%600;
			
		}
		this.x = (600 + this.x)%600;
		this.y = (450 + this.y)%450;

	}
	
	this.colision = function(x,y){
		var distancia=Math.sqrt( Math.pow( (x-this.x), 2)+Math.pow( (y-this.y),2));
		if(distancia>this.img[this.sprite].width)
		   return false;
		else
		   return true;	
	}
}
